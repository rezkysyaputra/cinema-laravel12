<x-app-layout>
    @livewire('booking-form', ['screening' => $screening])
    <x-footer />
</x-app-layout>
